package com.company;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Objects;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class GeoLocator {
    private static final String BASE_URL = "http://api.openweathermap.org/geo/1.0";
    private String apiKey="df6470b720c09fe0fe25ccf6d3c57d87";


    public GeoLocator(String apiKey) {
        this.apiKey = apiKey;
    }

    public String directGeocode(String query) throws IOException {
        String url = String.format(Locale.US, "%s/direct?q=%s&limit=1&appid=%s", BASE_URL, URLEncoder.encode(query, StandardCharsets.UTF_8), apiKey);
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(url).build();
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }

            JsonArray resultArray;
            resultArray = JsonParser.parseString(Objects.requireNonNull(response.body()).string()).getAsJsonArray();
            if (resultArray.size() > 0) {
                JsonObject resultObject = resultArray.get(0).getAsJsonObject();
                double lat = resultObject.get("lat").getAsDouble();
                double lon = resultObject.get("lon").getAsDouble();
                return String.format(Locale.US, "%.6f,%.6f", lat, lon);
            } else {
                return "Keine Ergebnisse gefunden.";
            }

        }
    }
}
