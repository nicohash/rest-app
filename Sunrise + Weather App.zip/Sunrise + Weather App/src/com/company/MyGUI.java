package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class MyGUI extends JFrame {
    private final JLabel label;
    private final JTextField textField;
    private final JButton button;

    public MyGUI() {
        super("Sunrise + Weather App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel imagePanel = new JPanel();
        ImageIcon icon = new ImageIcon("/Users/fabianbintz/Downloads/Moving weather.gif");
        JLabel imageLabel = new JLabel(icon);
        imagePanel.add(imageLabel);
        getContentPane().add(imagePanel, BorderLayout.CENTER);

        JPanel panel = new JPanel(new FlowLayout());
        label = new JLabel("Please enter the City you want the coordinates from!");
        panel.add(label);

        textField = new JTextField(20);
        panel.add(textField);

        button = new JButton("Calculate");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String cityName = textField.getText();
                    GeoLocator geoLocator = new GeoLocator("df6470b720c09fe0fe25ccf6d3c57d87");
                    String coordinates = geoLocator.directGeocode(cityName);
                    String input = coordinates;
                    String[] parts = input.split(",");
                    float latitude = Float.parseFloat(parts[0]);
                    float longitude = Float.parseFloat(parts[1]);

                    // Make API request to get sunrise time
                    String apiUrl = "https://api.sunrise-sunset.org/json?lat=36.7201600&lng=-4.4203400&formatted=0" + latitude + "&lng=" + longitude;
                    URL url = new URL(apiUrl);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String inputLine;
                    StringBuilder response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();

                    // Parse JSON response
                    JSONObject jsonObject = new JSONObject(response.toString());
                    JSONObject results = jsonObject.getJSONObject("results");
                    String sunriseTime = results.getString("sunrise");
                    String sunsetTime = results.getString("sunset");
                    String solarNoon = results.getString("solar_noon");
                    String dayLength = results.getString("day_length");
                    String civilTwilightBegin = results.getString("civil_twilight_begin");
                    String civilTwilightEnd = results.getString("civil_twilight_end");
                    String nauticalTwilightBegin = results.getString("nautical_twilight_begin");
                    String nauticalTwilightEnd = results.getString("nautical_twilight_end");
                    String astronomicalTwilightBegin = results.getString("astronomical_twilight_begin");
                    String astronomicalTwilightEnd = results.getString("astronomical_twilight_end");
                    String status = jsonObject.getString("status");

                    label.setText("The Coordinates for " + cityName + " are " + latitude + " , " + longitude + ". Sunrise time is " + sunriseTime+ ". Sunset time is "+ sunsetTime);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        panel.add(button);

        getContentPane().add(panel, BorderLayout.SOUTH);

        pack();
        setVisible(true);
    }
}


